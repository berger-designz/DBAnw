package at.fhj.swd15;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import at.fhj.persistence.StockRepository;

public class StockTest {
	
	static final int id = 1;
	static final int stockno = 20000;
	static final int barcode = 1;
	static StockRepository stockRep;
	static Stock stock;
	
	private static EntityManager manager = null;
    private static EntityManagerFactory factory= null;
    
    @BeforeClass 
	public static void setup()
    {
    	stockRep   = new StockRepository();
		   
    }
	
	@AfterClass 
	public static void teardown()
	{
		if (manager  != null) 
		{ 
			manager. close(); manager  = null; 
		}
        
		if (factory != null) 
		{ 
			factory.close(); factory = null; 
		}
    }
	
	@Test 
	public void selectStockByStocknoTest()
    {
		stock = stockRep.selectStockByStockno(stockno);
		String expected = "Stock ID: 1 Stockno: 20000";

        assertNotNull (stock);
        assertEquals(expected, stock.toString());

    }
	
	@Test 
	public void selectStockBCTest()
    {
		stock = stockRep.selectStockBC(barcode);
		//String expected = "Stock ID: 1 Stockno: 20000";

        assertNotNull (stock);
        System.out.println("Test :" + stock);
        //assertEquals(expected, stock.toString());

    }

}
