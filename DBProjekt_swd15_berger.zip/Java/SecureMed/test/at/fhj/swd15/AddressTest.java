package at.fhj.swd15;

import static org.junit.Assert.*;
import java.util.List;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;

import at.fhj.persistence.AddressRepository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

public class AddressTest 
{
	static final int id = 2; 
	static final int zip = 8010; 
	static final String country   = "Austria";
	static final String city   = "Frohnleiten";
	static final String street   = "Wienerstrasse 1";
	
	static AddressRepository addrRep;
	static Address addr1;
	static List<Address> adressList;
	private static EntityManager manager = null;
    private static EntityManagerFactory factory= null;
	
	@BeforeClass 
	public static void setup()
    {
		addrRep   = new AddressRepository();
		   
    }
	
	@AfterClass 
	public static void teardown()
	{
		if (manager  != null) 
		{ 
			manager. close(); manager  = null; 
		}
        
		if (factory != null) 
		{ 
			factory.close(); factory = null; 
		}
    }
	
	@Test 
	public void create ()
    {

		addr1 = addrRep.create(id, zip, country, city, street);

        assertNotNull (addr1);

    }
	
	@Test 
	public void selectAddressListTest()
    {

		adressList = addrRep.selectAddressList();

        assertNotNull (adressList);
        System.out.println("Test :" + adressList);

    }
	
	@Test 
	public void selectAddressByCityTest()
    {

		adressList = addrRep.selectAddressByCity(city);

        assertNotNull (adressList);
        System.out.println("TestCity :" + adressList);

    }
}
