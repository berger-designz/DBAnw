-- Drop the database WebShop
DROP DATABASE SecureMed;

-- Create the database WebShop
CREATE DATABASE SecureMed;

-- Create table Address
CREATE TABLE address
(
	Id int NOT NULL PRIMARY KEY,
	Zip int,
	City varchar(255),
	Country varchar(255),
	Street varchar(255)
);

-- Create table Produser
CREATE TABLE producer
(
	Id int NOT NULL PRIMARY KEY,
	Name varchar(255),
	ProductID_ID int,
	AddressID_ID int,
	FOREIGN KEY (AddressID_ID) REFERENCES address (Id)
);

-- Create table Supplier
CREATE TABLE supplier
(
	Id int NOT NULL PRIMARY KEY,
	Name varchar(255),
	AddressID int,
	FOREIGN KEY (AddressID) REFERENCES address (Id)
);

-- Create table Apothecaryshop
CREATE TABLE apothecaryshop
(
	Id int NOT NULL PRIMARY KEY,
	Company varchar(255),
	FirstName varchar(255),
	LastName varchar(255),
	AddressID int,
	FOREIGN KEY (AddressID) REFERENCES address (Id)
);

-- Create table ProductCategory
CREATE TABLE productCategory
(
	Id int NOT NULL PRIMARY KEY,
	Name varchar(255)
);

-- Create table Product
CREATE TABLE product
(
	Id int NOT NULL PRIMARY KEY,
	Name varchar(255),
	Itemnumber int,
	SupplierID int,
	ProducerID_ID int,
	ProductCategoryID_ID int,
	FOREIGN KEY (SupplierID) REFERENCES supplier (Id),
	FOREIGN KEY (ProducerID_ID) REFERENCES producer (Id),
	FOREIGN KEY (ProductCategoryID_ID) REFERENCES productCategory (Id)
);

-- Create table Barcode
CREATE TABLE barcode
(
	Id int NOT NULL PRIMARY KEY,
	Barcode varchar(255)
);

-- Create table Stock
CREATE TABLE stock
(
	Id int NOT NULL PRIMARY KEY,
	Stockno int,
	Charge int,
	Expirydate timestamp,
	QTY int,
	BarcodeID_ID int,
	ProductID_ID int,
	FOREIGN KEY (BarcodeID_ID) REFERENCES barcode (Id)
);

CREATE SEQUENCE Address_Sequence START WITH 1 INCREMENT BY 1;
ALTER TABLE Address ALTER COLUMN id SET DEFAULT nextval('Address_Sequence');

--Insert data
INSERT INTO address VALUES(1, 8010, 'Graz', 'Austria', 'Wienerstrasse 1');
INSERT INTO apothecaryshop VALUES(1, 'BergerDB', 'Rudolf', 'Berger', 1);
INSERT INTO address VALUES(2, 8010, 'Graz', 'Austria', 'Wienerstrasse 66');
INSERT INTO apothecaryshop VALUES(2, 'DB', 'Mani', 'Berger', 2);
INSERT INTO address VALUES(3, 8131, 'Frohnleiten', 'Austria', 'R�thelstein 66');
INSERT INTO producer VALUES(3, 'Test', 1, 3);
INSERT INTO address VALUES(4, 8131, 'Frohnleiten', 'Austria', 'Frohnleiten 25');
INSERT INTO supplier VALUES(1, 'SupplierTest', 4);
INSERT INTO productcategory VALUES(1, 'Productcategory1');
INSERT INTO product VALUES(1, 'Product1', 10000, 1, 3, 1);
INSERT INTO barcode VALUES(1, 'wc1451b');
INSERT INTO stock VALUES(1, 20000, 223344, '12.12.2020', 500, 1, 1);