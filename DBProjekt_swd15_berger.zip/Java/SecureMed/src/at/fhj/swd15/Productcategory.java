package at.fhj.swd15;

import javax.persistence.*;

@Entity @Table(name="PRODUCTCATEGORY") 
public class Productcategory 
{
	@SequenceGenerator 
	(name = "ProductcategoryIdGenerator", sequenceName = "Productcategory_Sequence", allocationSize = 1)
	 
	  
	@Id @GeneratedValue(generator = "ProductcategoryIdGenerator")
	private int id; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id == 0)
			throw new IllegalArgumentException();
		this.id = id;
	}
	
	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		if(name == null)
			throw new NullPointerException();
		this.name = name;
	}
	
	@OneToOne ( mappedBy = "productcategoryID") 
	private Product productID; 
	public Product getproductID() {
		return productID;
	}

	public void setproductID(Product productID) {
		if(productID == null)
			throw new NullPointerException();
		this.productID = productID;
	}
	
	protected Productcategory(){}
	
	public Productcategory(int id, String name)
	{
		this.setId(id);
		this.setName(name);
	}
}
