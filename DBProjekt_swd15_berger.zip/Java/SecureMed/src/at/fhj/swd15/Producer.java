package at.fhj.swd15;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.*;

@Entity @Table(name="PRODUCER") 
public class Producer 
{
	@SequenceGenerator 
	(name = "ProducerIdGenerator", sequenceName = "Producer_Sequence", allocationSize = 1)
	 
	  
	@Id @GeneratedValue(generator = "ProducerIdGenerator")
	private int id; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id == 0)
			throw new IllegalArgumentException();
		this.id = id;
	}
	
	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		if(name == null)
			throw new NullPointerException();
		this.name = name;
	}
	
	@OneToOne
	private Address addressID; 
	public Address getApothecaryShop() {
		return addressID;
	}

	public void setApothecaryShop(Address addressID) {
		if(addressID == null)
			throw new NullPointerException();
		this.addressID = addressID;
	}
	
	@OneToMany(mappedBy = "producerID")    
	private Collection<Product> productIDs  = new ArrayList<Product>();   

	public Collection<Product> getProductIDs() {
		return productIDs;
	}

	public void addProductID(Product productID) {
		if(productID == null)
			throw new NullPointerException();
		productIDs.add(productID);
	}

	protected Producer(){}
	
	public Producer(int id, String name)
	{
		this.setId(id);
		this.setName(name);
	}
}
