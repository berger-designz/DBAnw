package at.fhj.swd15;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.*;

@Entity @Table(name="PRODUCT") 
public class Product 
{
	@SequenceGenerator 
	(name = "ProductIdGenerator", sequenceName = "Product_Sequence", allocationSize = 1)
	 
	@Id @GeneratedValue(generator = "ProductIdGenerator")
	private int id; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id == 0)
			throw new IllegalArgumentException();
		this.id = id;
	}
	
	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		if(name == null)
			throw new NullPointerException();
		this.name = name;
	}
	
	private int itemnumber;
	public int getItemnumber() {
		return itemnumber;
	}

	public void setItemnumber(int itemnumber) {
		if(itemnumber == 0)
			throw new IllegalArgumentException();
		this.itemnumber = itemnumber;
	} 
	
	@OneToOne
	private Productcategory productcategoryID; 
	public Productcategory getApothecaryShop() {
		return productcategoryID;
	}
	
	@ManyToOne
	private Producer producerID;
	public Producer getProducer() {
		return producerID;
	}
	public void setProducer(Producer producerID) {
		if(producerID == null)
			throw new NullPointerException();
		this.producerID = producerID;
		producerID.addProductID(this);
	}
	
	@OneToMany(mappedBy = "productID")    
	private Collection<Stock> stockIDs  = new ArrayList<Stock>();   

	public Collection<Stock> getProductIDs() {
		return stockIDs;
	}

	public void addStockID(Stock stockID) {
		if(stockID == null)
			throw new NullPointerException();
		stockIDs.add(stockID);
	}
	
	@ManyToMany   
	private Collection<Supplier> supplierIDs  = new ArrayList<Supplier>();   

	public Collection<Supplier> getSupplierIDs() {
		return supplierIDs;
	}

	public void addSupplierID(Supplier supplierID) {
		if(supplierID == null)
			throw new NullPointerException();
		supplierIDs.add(supplierID);
		supplierID.addProductID(this);
	}
	
	protected Product(){}
	
	public Product(int id, String name)
	{
		this.setId(id);
		this.setName(name);
	}
}
