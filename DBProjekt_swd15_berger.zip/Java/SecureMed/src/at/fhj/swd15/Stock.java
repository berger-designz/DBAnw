package at.fhj.swd15;

import javax.persistence.*;

@NamedQueries({
	@NamedQuery 
	( name="Stock.findByStockno", query = "SELECT s FROM Stock s " + 
			"WHERE  s.stockno = :stockno"),
		
	//Problem with Join
	/*@NamedQuery 
	( name="Stock.findByStocknoBC", query = "SELECT s.barcodeid_id FROM Stock s JOIN s.barcodeid b" + 
			"WHERE s.barcodeid = :barcodeid")*/
})

@Entity @Table(name="STOCK")
public class Stock 
{
	@SequenceGenerator 
	(name = "StockIdGenerator", sequenceName = "Stock_Sequence", allocationSize = 1)
	 
	@Id @GeneratedValue(generator = "StockIdGenerator")
	private int id; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id == 0)
			throw new IllegalArgumentException();
		this.id = id;
	}
	
	private int qty;
	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		if(qty == 0)
			throw new IllegalArgumentException();
		this.qty = qty;
	}
	
	private int charge;
	public int getCharge() {
		return charge;
	}

	public void setCharge(int charge) {
		if(charge == 0)
			throw new IllegalArgumentException();
		this.charge = charge;
	}
	
	private int stockno;
	public int getStockno() {
		return stockno;
	}

	public void setStockno(int stockno) {
		if(stockno == 0)
			throw new IllegalArgumentException();
		this.stockno = stockno;
	}
	
	@OneToOne
	private Barcode barcodeID; 
	public Barcode getApothecaryShop() {
		return barcodeID;
	}
	
	@ManyToOne
	private Product productID;
	public Product getProducer() {
		return productID;
	}
	public void setProducer(Product productID) {
		if(productID == null)
			throw new NullPointerException();
		this.productID = productID;
		productID.addStockID(this);
	}
	
	protected Stock(){}
	
	public Stock(int id, int qty, int charge, int stockno)
	{
		this.setId(id);
		this.setQty(qty);
		this.setCharge(charge);
		this.setStockno(stockno);
	}
	
	@Override
    public String toString() {

        String string = "Stock ID: " + getId() + " Stockno: " + getStockno();

        return string;

    }
}
