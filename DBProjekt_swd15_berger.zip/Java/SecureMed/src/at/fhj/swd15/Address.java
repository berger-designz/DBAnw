package at.fhj.swd15;

import javax.persistence.*;

@NamedQuery 
( name="Address.findByCity", query = "SELECT a FROM Address a " + 
				"WHERE  a.city = :city")

@Entity @Table(name="ADDRESS") 
public class Address {
	
	@SequenceGenerator 
	(name = "AddressIdGenerator", sequenceName = "Address_Sequence", allocationSize = 1)
	  
	@Id @GeneratedValue(generator = "AddressIdGenerator")
	@Column(name = "ID") private int id; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id == 0)
			throw new IllegalArgumentException();
		this.id = id;
	}
	
	@Column(name = "COUNTRY") private String country; 
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		if(country == null)
			throw new NullPointerException();
		this.country = country;
	}
	
	@Column(name = "CITY") private String city; 
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		if(city == null)
			throw new NullPointerException();
		this.city = city;
	}
	
	@Column(name = "ZIP") private int zip;
	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		if(zip == 0)
			throw new IllegalArgumentException();
		this.zip = zip;
	}
	
	@Column(name = "STREET") private String street;
	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		if(street == null)
			throw new NullPointerException();
		this.street = street;
	}
	

	protected Address() {}
	    
	public Address (int id, int zip, String country, String city, String street)
	{    
		this.setId(id);
		this.setZip(zip);
		this.setCountry(country);
		this.setCity(city);
		this.setStreet(street);
	}
	
	@Override public String toString() 
	{
		String string = "Address id: " + getId() + " zip: " + getZip() + " country: " + getCountry()  +
						" city: " + getCity()  + " street: " + getStreet();

        return string;
	}

}
