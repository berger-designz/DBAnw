package at.fhj.swd15;

import javax.persistence.*;


@Entity @Table(name="APOTHECARYSHOP") 
public class ApothecaryShop {
	
	@SequenceGenerator 
	(name = "ApothecaryshopIdGenerator", sequenceName = "Apothecary_Sequence", allocationSize = 1)
	 
	  
	@Id @GeneratedValue(generator = "ApothecaryshopIdGenerator")
	private int id; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id == 0)
			throw new IllegalArgumentException();
		this.id = id;
	}
	
	private String company;
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		if(company == null)
			throw new NullPointerException();
		this.company = company;
	}
	
	private String firstname;
	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		if(firstname == null)
			throw new NullPointerException();
		this.firstname = firstname;
	}
	
	private String lastname;
	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		if(lastname == null)
			throw new NullPointerException();
		this.lastname = lastname;
	}
	
	@OneToOne
	private Address addressID; 
	public Address getApothecaryShop() {
		return addressID;
	}

	public void setApothecaryShop(Address addressID) {
		if(addressID == null)
			throw new NullPointerException();
		this.addressID = addressID;
	}

	protected ApothecaryShop(){}
	
	public ApothecaryShop(int id, String company, String firstname, String lastname)
	{
		this.setId(id);
		this.setCompany(company);
		this.setFirstname(firstname);
		this.setLastname(lastname);
	}
}
