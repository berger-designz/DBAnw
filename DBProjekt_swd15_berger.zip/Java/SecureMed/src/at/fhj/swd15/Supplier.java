package at.fhj.swd15;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.*;

@Entity @Table(name="SUPPLIER")
public class Supplier 
{
	@SequenceGenerator 
	(name = "SupplierIdGenerator", sequenceName = "Supplier_Sequence", allocationSize = 1)
	 
	  
	@Id @GeneratedValue(generator = "SupplierIdGenerator")
	private int id; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id == 0)
			throw new IllegalArgumentException();
		this.id = id;
	}
	
	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		if(name == null)
			throw new NullPointerException();
		this.name = name;
	}
	
	@OneToOne
	private Address addressID; 
	public Address getAddress() {
		return addressID;
	}

	public void setAddress(Address addressID) {
		if(addressID == null)
			throw new NullPointerException();
		this.addressID = addressID;
	}
	
	@ManyToMany(mappedBy = "supplierIDs")    
	private Collection<Product> productIDs  = new ArrayList<Product>();   

	public Collection<Product> getProductIDs() {
		return productIDs;
	}

	public void addProductID(Product productID) {
		if(productID == null)
			throw new NullPointerException();
		productIDs.add(productID);
		productID.addSupplierID(this);
	}
	
	protected Supplier(){}
	
	public Supplier(int id, String name)
	{
		this.setId(id);
		this.setName(name);
	}
}
