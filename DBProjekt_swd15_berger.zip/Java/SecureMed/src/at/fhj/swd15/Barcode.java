package at.fhj.swd15;

import javax.persistence.*;

@Entity @Table(name="BARCODE") 
public class Barcode 
{
	@SequenceGenerator 
	(name = "BarcodeIdGenerator", sequenceName = "Barcode_Sequence", allocationSize = 1)
	 
	  
	@Id @GeneratedValue(generator = "BarcodeIdGenerator")
	private int id; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id == 0)
			throw new IllegalArgumentException();
		this.id = id;
	}
	
	private String barcode;
	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		if(barcode == null)
			throw new NullPointerException();
		this.barcode = barcode;
	}
	
	protected Barcode(){}
	
	public Barcode(int id, String barcode)
	{
		this.setId(id);
		this.setBarcode(barcode);
	}
}
