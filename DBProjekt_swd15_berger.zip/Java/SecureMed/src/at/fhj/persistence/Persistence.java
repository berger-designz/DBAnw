package at.fhj.persistence;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.*;

public class Persistence 
{
	private static EntityManager manager = null;
    private static EntityManagerFactory factory= null;
    public static final String persistenceUnit = "SecureMed";
    
    public static EntityManager connect ()
    {
        if (factory == null)
        {
        	factory = javax.persistence.Persistence.createEntityManagerFactory (persistenceUnit);

        	manager  = factory.createEntityManager();
        }

        return manager;
    }
    
    public static EntityManager connect (String user, String password)
    {
    	if (factory == null)
    	{
    		Map<String, String> props = new HashMap<String, String>();

    		props.put ("javax.persistence.jdbc.user",     user);
    		props.put ("javax.persistence.jdbc.password", password);

    		factory = javax.persistence.Persistence.createEntityManagerFactory(persistenceUnit, props);

    		manager  = factory.createEntityManager();
    	}

    	return manager;
    }

}
