package at.fhj.persistence;

import javax.persistence.*;

public abstract class Repository<T>
{
	
	protected EntityManager entityManager;
	protected Class<T> entityClass;
	
	public Repository(Class<T> entityClass)
	{
		this.entityClass = entityClass;
		entityManager = Persistence.connect();
	}
	
	public Repository(Class<T> entityClass, String user, String password)
	{
		this.entityClass = entityClass;
		entityManager = Persistence.connect(user, password);
	}
	
	public T find(int id) {
        return entityManager.find ( entityClass , id);
    }
	
}
