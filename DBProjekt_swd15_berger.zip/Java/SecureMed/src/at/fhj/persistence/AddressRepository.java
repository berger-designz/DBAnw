package at.fhj.persistence;

import java.util.List;

import javax.persistence.TypedQuery;

import at.fhj.swd15.Address;

public class AddressRepository extends Repository<Address>
{
	public AddressRepository()
    {
        super(Address.class);
    }
	
	public Address create(int id, int zip, String country, String city, String street)
    {
		Address address = new Address(id, zip, country, city, street);

        entityManager.persist(address);

        return address;
    }
	
	public List<Address> selectAddressList()
    {
		TypedQuery<Address> query =
				entityManager.createQuery("SELECT a FROM Address a", Address.class);
			  List<Address> results = query.getResultList();

        return results;
    }
	
	public List<Address> selectAddressByCity(String city)
    {
		TypedQuery<Address> query =  
				 entityManager.createNamedQuery("Address.findByCity" ,Address.class ).setParameter("city", city);
		List<Address> result = query.getResultList();
		
        return  result;
    }

	
}
