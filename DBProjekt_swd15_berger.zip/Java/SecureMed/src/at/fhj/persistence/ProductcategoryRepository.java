package at.fhj.persistence;

import at.fhj.swd15.Productcategory;

public class ProductcategoryRepository extends Repository<Productcategory>
{
	public ProductcategoryRepository()
    {
        super(Productcategory.class);
    }
}
