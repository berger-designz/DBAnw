package at.fhj.persistence;

import javax.persistence.TypedQuery;

import at.fhj.swd15.Stock;

public class StockRepository extends Repository<Stock>
{
	public StockRepository()
    {
        super(Stock.class);
    }
	
	public Stock selectStockByStockno(int stockno)
    {
		TypedQuery<Stock> query =  
				 entityManager.createNamedQuery("Stock.findByStockno" ,Stock.class ).setParameter("stockno", stockno);
		Stock result = query.getSingleResult();
		
        return result;
    }
	
	public Stock selectStockBC(int barcode)
    {
		TypedQuery<Stock> query =  
				 entityManager.createNamedQuery("Stock.findByStocknoBC" ,Stock.class ).setParameter("barcodeid", barcode);
		Stock result = query.getSingleResult();
		
        return result;
    }
}
