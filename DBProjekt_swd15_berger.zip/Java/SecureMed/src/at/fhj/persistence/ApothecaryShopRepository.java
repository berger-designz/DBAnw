package at.fhj.persistence;

import at.fhj.swd15.ApothecaryShop;

public class ApothecaryShopRepository extends Repository<ApothecaryShop>
{
	public ApothecaryShopRepository()
    {
        super(ApothecaryShop.class);
    }
	
}
