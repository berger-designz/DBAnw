package at.fhj.persistence;

import at.fhj.swd15.Supplier;

public class SupplierRepository extends Repository<Supplier>
{
	public SupplierRepository()
    {
        super(Supplier.class);
    }
}
