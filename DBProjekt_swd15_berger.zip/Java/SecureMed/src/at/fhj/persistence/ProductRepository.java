package at.fhj.persistence;

import at.fhj.swd15.Product;

public class ProductRepository extends Repository<Product>
{
	public ProductRepository()
    {
        super(Product.class);
    }
}
