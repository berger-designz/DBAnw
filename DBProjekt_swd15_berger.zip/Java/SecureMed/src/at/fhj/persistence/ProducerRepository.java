package at.fhj.persistence;

import at.fhj.swd15.Producer;

public class ProducerRepository extends Repository<Producer>
{
	public ProducerRepository()
    {
        super(Producer.class);
    }
	
}



