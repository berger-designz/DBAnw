package at.fhj.persistence;

import at.fhj.swd15.Barcode;

public class BarcodeRepository extends Repository<Barcode>
{
	public BarcodeRepository()
    {
        super(Barcode.class);
    }
}
